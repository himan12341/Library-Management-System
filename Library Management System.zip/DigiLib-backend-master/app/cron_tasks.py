# from app.books.crud import BookTransactionsCrud
# from app.db import BookItem, BookTransaction, Book


def calculate_fine_dues(a):
    
    """
    Calculate fine dues for a transaction
    """
    print(a)
    # book_trans = BookTransactionsCrud.get(trans_id)
    # print(book_trans)
    
    
